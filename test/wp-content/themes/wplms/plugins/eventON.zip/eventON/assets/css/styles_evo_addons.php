<?php
/**
 * EventON Styles for all addons in one place in one file
 * @version 2.5
 */

do_action('evo_addon_styles');